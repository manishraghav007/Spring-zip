package com.luv2code.springcoredemo.common;

public interface Coach {

    String getDailyWorkout();
}
